package amis.fr.projetTp6_7_8.repository;

import amis.fr.projetTp6_7_8.entity.Customer;
import amis.fr.projetTp6_7_8.entity.Login;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Repository
public class CustomerDao implements ICustomerDao{

    private ArrayList<Customer> customersList = new ArrayList<>();
    @Override
    public void insertCustomers(Customer customer){
        customersList.add(customer);
    }

    @Override
    public Customer findByName(String name){
        for (Customer item : customersList){
            if (item.getName().equals(name)){
                return item;
            }
        }
        return null;
    }

    @Override
    public Customer findByid(int id){
        for (Customer item : customersList){
            if (item.getId() == id){
                return item;
            }
        }
        return null;
    }

    @Override
    public boolean isValid(Customer customer) {
        for (Customer item : customersList) {
            if (item.getId() == customer.getId()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public List<Customer> listAllCustomer(){
        return customersList;
    }

    @Override
    public int countCustomers(){
        return customersList.size();
    }

    @Override
    public boolean deleteCustomer(Customer customer) {
        Iterator<Customer> iterator = customersList.iterator();

        while (iterator.hasNext()) {
            Customer item = iterator.next();
            if (item.getId() == customer.getId()) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }




    @Override
    public <S extends Customer> S save(S s) {
        return null;
    }

    @Override
    public <S extends Customer> Iterable<S> saveAll(Iterable<S> iterable) {
        return null;
    }

    @Override
    public Optional<Customer> findById(Long aLong) {
        return Optional.empty();
    }

    @Override
    public boolean existsById(Long aLong) {
        return false;
    }

    @Override
    public Iterable<Customer> findAll() {
        return null;
    }

    @Override
    public Iterable<Customer> findAllById(Iterable<Long> iterable) {
        return null;
    }

    @Override
    public long count() {
        return 0;
    }

    @Override
    public void deleteById(Long id) {
        Iterator<Customer> iterator = customersList.iterator();

        while (iterator.hasNext()) {
            Customer item = iterator.next();
            if (item.getId() == id) {
                iterator.remove();
            }
        }
    }

    @Override
    public void delete(Customer customer) {

    }

    @Override
    public void deleteAll(Iterable<? extends Customer> iterable) {

    }

    @Override
    public void deleteAll() {

    }
}
