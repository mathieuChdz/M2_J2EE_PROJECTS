package amis.fr.projetTp6_7_8;

import amis.fr.projetTp6_7_8.entity.Customer;
import amis.fr.projetTp6_7_8.service.ServiceCustomer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CustomerTest {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext();
        appContext.scan("amis.fr.projetTp6_7_8");
        appContext.refresh();
        ServiceCustomer serviceCustomer = (ServiceCustomer) appContext.getBean("serviceCustomer");

        serviceCustomer.sauve(new Customer("toto", "toto.boss@gmail.com", "rue de la kiffance"));

    }
}