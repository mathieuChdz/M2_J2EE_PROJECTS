package entity;

public class Prof extends Personne{

    private int num_prof;

    public Prof(){}

    public int getNum_prof() {
        return num_prof;
    }

    public void setNum_prof(int num_prof) {
        this.num_prof = num_prof;
    }
}
