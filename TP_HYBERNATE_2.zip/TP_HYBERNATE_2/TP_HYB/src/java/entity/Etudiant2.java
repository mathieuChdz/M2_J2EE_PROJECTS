package entity;

public class Etudiant2 extends Personne2{

    private int num_etudiant;

    public Etudiant2(){}

    public int getNum_etudiant() {
        return num_etudiant;
    }

    public void setNum_etudiant(int num_etudiant) {
        this.num_etudiant = num_etudiant;
    }
}
