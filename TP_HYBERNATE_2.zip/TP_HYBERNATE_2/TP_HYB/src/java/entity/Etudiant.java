package entity;

public class Etudiant extends Personne{

    private int num_etudiant;

    public Etudiant(){}

    public int getNum_etudiant() {
        return num_etudiant;
    }

    public void setNum_etudiant(int num_etudiant) {
        this.num_etudiant = num_etudiant;
    }
}
