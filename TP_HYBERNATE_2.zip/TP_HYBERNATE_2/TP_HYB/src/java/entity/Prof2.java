package entity;

public class Prof2 extends Personne2{

    private int num_prof;

    public Prof2(){}

    public int getNum_prof() {
        return num_prof;
    }

    public void setNum_prof(int num_prof) {
        this.num_prof = num_prof;
    }
}
